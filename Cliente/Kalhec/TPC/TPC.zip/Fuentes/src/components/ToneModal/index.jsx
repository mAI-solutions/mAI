import SuperModal from "./SuperModal";

export default SuperModal;
