import ModuleSwitch from './ModuleSwitch';

export default ModuleSwitch;