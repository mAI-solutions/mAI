import ModuleSelect from './ModuleSelect';

export default ModuleSelect;