const Redaccion = () => {
  return (
    <>
      redaccion
    </>
  )
}

export default Redaccion