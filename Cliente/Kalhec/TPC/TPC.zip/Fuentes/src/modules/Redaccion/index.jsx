import Redaccion from './Redaccion';

export default Redaccion;