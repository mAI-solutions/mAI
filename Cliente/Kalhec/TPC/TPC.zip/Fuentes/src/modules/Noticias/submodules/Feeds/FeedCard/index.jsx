import FeedCard from './FeedCard'
export default FeedCard