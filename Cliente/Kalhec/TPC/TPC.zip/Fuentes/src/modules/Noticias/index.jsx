import Noticias from './Noticias'
export default Noticias