import Feeds from './Feeds'
export default Feeds