import Acciones from './Acciones'
export default Acciones