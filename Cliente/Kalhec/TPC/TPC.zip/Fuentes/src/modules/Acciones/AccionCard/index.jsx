import AccionCard from './AccionCard'
export default AccionCard