import PocketBase from 'pocketbase'

const pb = new PocketBase('http://143.198.141.62:8090')

export default pb