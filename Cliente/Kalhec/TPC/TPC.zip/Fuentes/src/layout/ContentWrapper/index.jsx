import ContentWrapper from './ContentWrapper';
export default ContentWrapper;