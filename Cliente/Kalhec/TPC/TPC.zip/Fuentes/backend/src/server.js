import PocketBase from 'pocketbase';

export const pb = new PocketBase('http://143.198.141.62:8090');
